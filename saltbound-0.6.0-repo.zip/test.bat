@echo off
call "%~dp0build.bat" runClient
